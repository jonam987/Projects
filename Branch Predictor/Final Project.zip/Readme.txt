*******ReadMe*******
This folder contains a framework folder and 3 other folders.

The framework folder contains all the files,traces and code required to run the predictor and obtain results.

The three other folders are Alpha,Gshare and TAGE.
--The 'Alpha' folder contains predictor.cc file which has the code for functions getprediction and updtateprediction for the DEC Alpha 21264 tournament predictor.
--The 'Gshare' folder contains predictor.cc file which has the code for functions getprediction and updtateprediction for the McFarling's gshare predictor. 
--The 'TAGE' folder contains predictor.cc file which has the code for functions getprediction and updtateprediction for the TAGE based hybrid predictor.

Copy the predictor.cc file from respective folder and paste it in the framework folder to compile and get predictions for the desired predictor
